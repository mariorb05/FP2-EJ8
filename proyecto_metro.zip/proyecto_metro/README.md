# Boletín 8 — Grafo del Metro de Madrid

Resolución del Boletín 8 (Fundamentos de Programación 2, semana del 4 de
mayo). Se modela el Metro de Madrid como un grafo y se trabaja con dos
representaciones distintas de la misma información (vista por líneas y
vista por estaciones), junto con métodos de consulta sobre el grafo.

## Estructura del proyecto

```
proyecto_metro/
├── README.md
├── datos/
│   └── líneas_y_estaciones_Metro_Madrid.xlsx   ← entrada
└── src/
    ├── estacion.py       (clase Estacion)
    ├── lineas.py         (clase Lineas)
    ├── estaciones.py     (clase Estaciones)
    └── main.py           (punto de entrada, sin funciones)
```

Cada clase vive en su propio fichero. El `main.py` no define funciones:
solo invoca métodos de las clases. La carpeta `datos/` está separada de
`src/` porque los datos no son código fuente.

## Cómo ejecutar

Requiere Python 3.7+ y `openpyxl`:

```bash
pip install openpyxl
cd src
python main.py
```

## Formato esperado del Excel

| Linea | Num_Estaciones | Estacion          | Circular |
|-------|----------------|-------------------|----------|
| L1    | 33             | Pinar de Chamartín|          |
| L1    | 33             | Bambú             |          |
| ...   | ...            | ...               |          |
| L6    | 28             | Argüelles         | Sí       |
| L6    | 28             | Moncloa           | Sí       |

- Columna A: nombre de la línea (se repite en cada fila de esa línea).
- Columna B: número total de estaciones declarado para la línea (se
  utiliza para validar que coincide con las filas reales).
- Columna C: nombre de la estación (en orden).
- Columna D (opcional): "Sí" si la línea es circular.

> **Nota sobre el dataset incluido:** el Excel adjunto contiene 7 líneas
> reales del Metro de Madrid (L1, L2, L3, L6, L8, L11 y Ramal Ópera —
> Príncipe Pío) con todas sus estaciones. Es un subconjunto representativo
> que cubre todos los casos del enunciado: líneas largas, líneas cortas,
> una línea circular (L6), una línea terminal-aeropuerto (L8) y la
> propia Ramal. Sustituye este fichero por la versión completa del
> Excel original cuando lo desees: el código no asume el tamaño.

## Respuestas a las preguntas del enunciado

### ¿Cuál es la mejor estructura para guardar las estaciones de cada línea (orden importa)?

Un **diccionario `dict[str, list[Estacion]]`**, donde la clave es el
nombre de la línea y el valor es la **lista** ordenada de estaciones.

- `dict` da acceso O(1) a las estaciones de una línea por nombre.
- `list` preserva el orden — imprescindible para el recorrido del tren,
  los vecinos de una estación, los extremos y el cierre circular.

Implementado como atributo `_lineas` en la clase `Lineas`.

### ¿Cuál es la mejor estructura para guardar las líneas que pasan por cada estación (orden no importa)?

Un **diccionario `dict[Estacion, set[str]]`**, donde la clave es la
estación y el valor es el **conjunto** de líneas que pasan por ella.

- `dict` da acceso O(1) a las líneas de una estación.
- `set` evita duplicados (una línea no se cuenta dos veces aunque
  apareciera repetida en la fuente) y la pertenencia es O(1).

Implementado como atributo `_mapa` en la clase `Estaciones`.

### ¿En qué clases implementará las funciones de conversión?

- `Lineas.a_estaciones()` → vive en `Lineas` porque es esta vista la que
  posee la información completa (línea → secuencia de estaciones) y la
  reorganiza en la otra dirección.
- `Estaciones.a_lineas()` → vive en `Estaciones` por simetría: es esta
  vista la que tiene la información completa para emitir la otra.

Cada conversión está en la clase de **origen** (la que tiene los datos
crudos), porque es ahí donde el método tiene contexto suficiente.

### ¿En qué clases implementar `eliminar_linea` y `es_conexo`?

- `eliminar_linea` → en `Lineas`. Eliminar una línea es modificar la
  estructura de "vista por líneas". Devolvemos un objeto **nuevo** (no
  mutamos `self`) para evitar efectos colaterales.
- `es_conexo` (y `componentes_conexas`) → en `Estaciones`. La conexidad
  es una pregunta sobre el grafo entendido como conjunto de nodos
  (estaciones) y aristas. La vista de estación expone naturalmente los
  nodos. Para reconstruir las aristas se necesita un objeto `Lineas`
  como auxiliar (qué estaciones son contiguas dentro de cada línea), de
  ahí la firma `es_conexo(self, lineas_obj)`.

### Igualdad vs Identidad

Ver sección dedicada más abajo.

## Métodos implementados

### Clase `Estacion` (`src/estacion.py`)
| Método | Descripción |
|---|---|
| `nombre`, `latitud`, `longitud` | Propiedades de solo lectura |
| `tiene_coordenadas()` | True si están asignadas |
| `asignar_coordenadas(lat, lon)` | Permite añadir coordenadas a posteriori |
| `distancia_a(otra)` | Distancia **Haversine** en km (no euclídea) |
| `__eq__`, `__hash__` | Igualdad por nombre (permite usar como clave de dict) |

### Clase `Lineas` (`src/lineas.py`)
| Método | Descripción |
|---|---|
| `desde_excel(ruta)` | Constructor alternativo: carga y valida el Excel |
| `lineas()`, `estaciones_de(l)`, `num_estaciones(l)` | Consultas básicas |
| `todas_las_estaciones()` | Conjunto de estaciones (sin duplicar transbordos) |
| `es_circular(l)` | True si la línea está marcada o cierra sobre sí misma |
| `en_la_misma_linea(e1, e2)` | Lista de líneas comunes a ambas estaciones |
| `ruta_sin_transbordo(o, d)` | Línea + tramo de estaciones de origen a destino |
| `eliminar_linea(l)` | Devuelve un **nuevo** `Lineas` sin esa línea |
| `longitud_geografica(l)` / `linea_mas_larga()` | Suma de Haversines |
| `a_estaciones()` | Conversión a la vista `Estaciones` |
| `__eq__` | Igualdad por contenido |

### Clase `Estaciones` (`src/estaciones.py`)
| Método | Descripción |
|---|---|
| `estaciones()`, `lineas_de(e)`, `num_lineas(e)` | Consultas básicas |
| `estaciones_con_mas_lineas()` | Estaciones con más transbordos posibles |
| `es_conexo(lineas_obj)` | BFS sobre el grafo |
| `componentes_conexas(lineas_obj)` | Lista de componentes conexas |
| `criticidad_de_linea(lineas_obj, l)` | (huérfanas, proporción) si quito `l` |
| `linea_mas_critica(lineas_obj)` | Ranking de líneas por criticidad |
| `ruta_un_transbordo(...)` | Ruta con un solo transbordo |
| `ruta_n_transbordos(...)` | BFS sobre el **grafo de líneas** (generalización) |
| `a_lineas()` | Conversión a la vista `Lineas` |
| `__eq__` | Igualdad por contenido |

## Diferencia entre igualdad e identidad

Esta es la sección que el enunciado señala explícitamente. En Python
tenemos dos operadores muy parecidos pero conceptualmente distintos:

### `is` — **identidad**

`a is b` es `True` solo cuando `a` y `b` son **literalmente el mismo
objeto en memoria**, es decir, `id(a) == id(b)`. Equivale a preguntar
"¿son la misma referencia?".

```python
a = [1, 2, 3]
b = a            # b apunta al MISMO objeto que a
c = [1, 2, 3]    # c es OTRO objeto con el mismo contenido

a is b   # True   (misma referencia)
a is c   # False  (referencias distintas)
```

### `==` — **igualdad**

`a == b` invoca el método `__eq__` de la clase y compara el
**contenido**. Es responsabilidad del programador definir qué significa
"contenido igual" para cada clase.

```python
a == c   # True   (mismas listas elemento a elemento)
```

Por defecto Python hereda de `object` un `__eq__` que SOLO devuelve
`True` cuando `a is b` (igualdad por identidad). Si queremos que dos
objetos distintos representen "lo mismo" hay que sobrescribir `__eq__`.

### Cómo se usa en este proyecto

Las tres clases sobrescriben `__eq__` para definir igualdad por contenido:

- `Estacion.__eq__`: dos estaciones son iguales si tienen el mismo
  nombre. Esto es lo que permite que la conversión recíproca funcione,
  porque al reconstruir un objeto creamos `Estacion("Sol")` de cero y
  necesitamos que sea "igual" al `Estacion("Sol")` original.
- `Lineas.__eq__`: dos vistas son iguales si tienen las mismas líneas
  con las mismas estaciones (y los mismos circulares).
- `Estaciones.__eq__`: dos vistas son iguales si para cada estación
  contienen el mismo conjunto de líneas (y los mismos circulares).

El `main.py` lo demuestra al final de la sección 3:

```text
¿vista_lineas == vista_lineas_2 ?           -> True   ← misma información
¿vista_lineas is vista_lineas_2 ?           -> False  ← objetos distintos
id(vista_lineas)   = 140487774725152
id(vista_lineas_2) = 140487778178240        ← direcciones de memoria distintas
```

Esto es exactamente lo que pide el enunciado: invocar la conversión en
una dirección y luego en la otra produce un objeto **igual** al
original (`==` da True) pero **no idéntico** (`is` da False, los `id()`
son distintos). Si solo comparásemos con `is` concluiríamos
incorrectamente que el round-trip "no funciona", cuando en realidad
funciona perfectamente: simplemente fabrica un objeto nuevo con el
mismo contenido.

### Sobre la igualdad estricta de orden

En el enunciado se afirma que en `Lineas` "el orden importa". Es cierto
para las consultas (vecinos, extremos, recorridos). Sin embargo, la
otra vista (`Estaciones`) por definición **no almacena orden**, así que
la igualdad útil para comparar el resultado de un round-trip es la
**igualdad por pertenencia**: para cada línea, mismas estaciones (sin
exigir orden). Es la que se ha usado en `Lineas.__eq__`. Para una
comparación que exige también el orden interno se ofrece el método
auxiliar `Lineas.equivalente_estricto(otra)`.

## Coordenadas geográficas y distancia

La clase `Estacion` admite `latitud` y `longitud` opcionales. Con ellas
se calcula la **distancia Haversine** (la apropiada sobre la superficie
esférica de la Tierra; la euclídea sobre lat/lon **no** es válida):

```python
from math import radians, sin, cos, asin, sqrt
R = 6371.0  # km
a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
distancia = 2 * R * asin(sqrt(a))
```

Como menciona el enunciado, OpenStreetMap proporciona coordenadas para
casi todas las estaciones (excepto algunas del Metro Ligero). En este
proyecto la infraestructura está lista; solo hay que llamar a
`asignar_coordenadas(lat, lon)` sobre cada `Estacion` para empezar a
usar `distancia_a()`, `longitud_geografica(linea)` y `linea_mas_larga()`.

## Resultado al ejecutar `main.py`

Sobre el dataset incluido (7 líneas, 103 estaciones únicas) el programa
informa, entre otras cosas, de:

- **Estaciones con más líneas:** Sol (L1, L2, L3) y Cuatro Caminos (L1,
  L2, L6), ambas con 3 líneas.
- **Línea circular detectada:** L6.
- **Conexidad:** el grafo es conexo.
- **Línea más crítica:** L1 (deja 30 estaciones aisladas).
- **Si quito el Ramal:** el grafo permanece conexo y nadie queda
  aislado (los dos nodos del Ramal pertenecen también a L6 y a L2/L3).
- **Si quito L6:** el grafo se desconecta (la L8 cuelga del resto del
  sistema solo a través de Nuevos Ministerios y la propia L6).
- **Trayectos con transbordos:** ej. Aeropuerto T4 → Sol se hace en 2
  transbordos: L8 → (Nuevos Ministerios) → L6 → (Cuatro Caminos) → L1.
