"""
estaciones.py
-------------
Clase Estaciones: vista del grafo del Metro "por estación".

Para cada estación guardamos el CONJUNTO de líneas que pasan por ella.
El orden no importa: una estación pertenece a unas líneas, sin secuencia.

ESTRUCTURA DE DATOS ELEGIDA: dict[Estacion, set[str]]
  - Usamos dict porque así accedemos a las líneas de "Sol" en tiempo
    constante: self._estaciones_y_sus_lineas[Estacion("Sol")]
  - Dentro de cada clave usamos set porque el orden no importa
    y queremos evitar duplicados automáticamente.

EJERCICIOS DEL ENUNCIADO IMPLEMENTADOS AQUÍ
============================================
  ★ EJERCICIO 2b — Conversión Estaciones → Lineas        (a_lineas)
  ★ EJERCICIO 3  — Igualdad de contenido                 (__eq__)
  ★ EJERCICIO 4b — Estaciones con más líneas              (estaciones_con_mas_lineas)
  ★ EJERCICIO 6b — ¿El grafo es conexo?                   (es_conexo)
  ★ EJERCICIO 6c — Criticidad de una línea                (criticidad_de_linea / linea_mas_critica)
  ★ EJERCICIO 9  — Ruta con UN transbordo                 (ruta_un_transbordo)
  ★ EJERCICIO 10 — Ruta con N transbordos (generalización)(ruta_n_transbordos)
"""

from collections import defaultdict, deque


class Estaciones:

    def __init__(self, mapa=None, circulares=None):
        # Diccionario principal: estacion → conjunto de líneas que pasan por ella
        # Ejemplo: { Estacion("Sol"): {"Linea 1", "Linea 2", "Linea 3"}, ... }
        self._estaciones_y_sus_lineas = {}
        for estacion, conjunto_lineas in (mapa or {}).items():
            # Hacemos una copia del conjunto para no compartir referencias externas
            self._estaciones_y_sus_lineas[estacion] = set(conjunto_lineas)

        # Guardamos qué líneas son circulares para no perder ese dato
        # al convertir entre las dos vistas (Lineas ↔ Estaciones)
        self._lineas_circulares = set(circulares or set())

    # ------------------------------------------------------------------
    # Consultas básicas
    # ------------------------------------------------------------------
    def estaciones(self):
        """Devuelve la lista de todas las estaciones."""
        return list(self._estaciones_y_sus_lineas.keys())

    def lineas_de(self, estacion):
        """Devuelve el conjunto de líneas que pasan por una estación."""
        return set(self._estaciones_y_sus_lineas[estacion])

    def num_lineas(self, estacion):
        """Devuelve cuántas líneas pasan por una estación."""
        return len(self._estaciones_y_sus_lineas[estacion])

    def __contains__(self, estacion):
        """Permite usar 'if estacion in vista_estaciones'."""
        return estacion in self._estaciones_y_sus_lineas

    def __len__(self):
        """Permite usar len(vista_estaciones)."""
        return len(self._estaciones_y_sus_lineas)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 4b — Estaciones con más líneas
    # ★
    # ★ El enunciado dice: "puede empezar por ejercicios simples como
    # ★ cuál o cuáles son las estaciones con más líneas."
    # ★
    # ★ Devuelve una tupla: (número máximo, lista de estaciones empatadas)
    # ★ Puede haber varias estaciones empatadas en el máximo.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def estaciones_con_mas_lineas(self):
        """Devuelve (máximo_de_líneas, [estaciones_con_ese_máximo])."""
        if len(self._estaciones_y_sus_lineas) == 0:
            return 0, []

        # Paso 1: encontrar el máximo número de líneas que tiene alguna estación
        maximo_de_lineas = 0
        for conjunto_lineas in self._estaciones_y_sus_lineas.values():
            if len(conjunto_lineas) > maximo_de_lineas:
                maximo_de_lineas = len(conjunto_lineas)

        # Paso 2: recoger todas las estaciones que tienen ese máximo
        estaciones_ganadoras = []
        for estacion, conjunto_lineas in self._estaciones_y_sus_lineas.items():
            if len(conjunto_lineas) == maximo_de_lineas:
                estaciones_ganadoras.append(estacion)

        return maximo_de_lineas, estaciones_ganadoras

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 6b — ¿El grafo es conexo?
    # ★
    # ★ El enunciado dice: "chequear si un grafo es conexo (hay al
    # ★ menos una ruta entre cualesquiera dos estaciones)."
    # ★ Y también: "¿Si quito una línea seguiría siendo conexo?"
    # ★
    # ★ ALGORITMO — BFS (Búsqueda en Anchura):
    # ★   1. Empezamos en cualquier estación.
    # ★   2. Vamos expandiéndonos a sus vecinas, luego a las vecinas
    # ★      de las vecinas, etc., marcando las que ya hemos visto.
    # ★   3. Si al terminar hemos visitado TODAS las estaciones,
    # ★      el grafo es conexo. Si no, hay islas desconectadas.
    # ★
    # ★ Necesita un objeto Lineas para saber qué estaciones son
    # ★ contiguas dentro de cada línea (ese orden lo guarda Lineas).
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def es_conexo(self, lineas_obj):
        """Devuelve True si desde cualquier estación se puede llegar a cualquier otra."""
        if len(self._estaciones_y_sus_lineas) == 0:
            return True

        # Construimos el grafo de adyacencias: quién está al lado de quién
        grafo_adyacencias = self._construir_grafo(lineas_obj)

        # Empezamos el BFS desde la primera estación del diccionario
        estacion_inicial     = next(iter(self._estaciones_y_sus_lineas))
        estaciones_visitadas = {estacion_inicial}
        cola_de_pendientes   = deque([estacion_inicial])

        # Mientras haya estaciones por explorar en la cola...
        while len(cola_de_pendientes) > 0:
            estacion_actual = cola_de_pendientes.popleft()

            # Miramos cada vecina de la estación actual
            for estacion_vecina in grafo_adyacencias[estacion_actual]:
                if estacion_vecina not in estaciones_visitadas:
                    # Es nueva: la marcamos como visitada y la añadimos a la cola
                    estaciones_visitadas.add(estacion_vecina)
                    cola_de_pendientes.append(estacion_vecina)

        # Si hemos visitado todas las estaciones, el grafo es conexo
        return len(estaciones_visitadas) == len(self._estaciones_y_sus_lineas)

    def componentes_conexas(self, lineas_obj):
        """Devuelve una lista de grupos (sets) de estaciones.
        Cada grupo es una isla: hay ruta entre sus estaciones pero
        no hay ruta hacia estaciones de otros grupos."""
        grafo_adyacencias        = self._construir_grafo(lineas_obj)
        estaciones_ya_visitadas  = set()
        lista_de_grupos          = []

        for estacion_inicio in self._estaciones_y_sus_lineas:
            # Si ya la visitamos en un BFS anterior, pertenece a un grupo anterior
            if estacion_inicio in estaciones_ya_visitadas:
                continue

            # Empezamos un nuevo BFS → nuevo grupo
            grupo_actual       = set()
            cola_de_pendientes = deque([estacion_inicio])
            estaciones_ya_visitadas.add(estacion_inicio)

            while len(cola_de_pendientes) > 0:
                estacion_actual = cola_de_pendientes.popleft()
                grupo_actual.add(estacion_actual)

                for estacion_vecina in grafo_adyacencias[estacion_actual]:
                    if estacion_vecina not in estaciones_ya_visitadas:
                        estaciones_ya_visitadas.add(estacion_vecina)
                        cola_de_pendientes.append(estacion_vecina)

            lista_de_grupos.append(grupo_actual)

        return lista_de_grupos

    def _construir_grafo(self, lineas_obj):
        """Método auxiliar (privado, por eso empieza con _).
        Construye un diccionario estacion → set(estaciones vecinas).
        Dos estaciones son vecinas si aparecen contiguas en alguna línea."""
        grafo_adyacencias = defaultdict(set)

        # Primero añadimos todas las estaciones al grafo aunque no tengan
        # vecinas todavía (pueden haberse quedado aisladas al eliminar líneas)
        for estacion in self._estaciones_y_sus_lineas:
            grafo_adyacencias[estacion]

        # Recorremos cada línea y conectamos sus estaciones contiguas
        for nombre_linea in lineas_obj.lineas():
            lista_estaciones = lineas_obj.estaciones_de(nombre_linea)

            # Conectamos cada estación con la siguiente de la lista
            # Ejemplo: [A, B, C, D] → conectamos A-B, B-C, C-D
            for i in range(len(lista_estaciones) - 1):
                estacion_a = lista_estaciones[i]
                estacion_b = lista_estaciones[i + 1]
                # La conexión es en los dos sentidos (grafo no dirigido)
                grafo_adyacencias[estacion_a].add(estacion_b)
                grafo_adyacencias[estacion_b].add(estacion_a)

            # Si la línea es circular, conectamos también la última con la primera
            if lineas_obj.es_circular(nombre_linea) and len(lista_estaciones) > 2:
                primera = lista_estaciones[0]
                ultima  = lista_estaciones[-1]
                grafo_adyacencias[primera].add(ultima)
                grafo_adyacencias[ultima].add(primera)

        return grafo_adyacencias

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 6c — Criticidad de una línea
    # ★
    # ★ El enunciado dice: "cuál es la línea que si se suprime deja
    # ★ más estaciones aisladas. Se puede calcular en número absoluto
    # ★ o en proporción al número de paradas de la línea."
    # ★
    # ★ Una estación queda "huérfana" si, al eliminar esa línea,
    # ★ ya no pertenece a ninguna otra → queda completamente aislada.
    # ★
    # ★ linea_mas_critica aplica esto a todas las líneas y devuelve
    # ★ la tabla ordenada de mayor a menor criticidad.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def criticidad_de_linea(self, lineas_obj, linea):
        """Devuelve (nº de estaciones huérfanas, proporción sobre el total)."""
        total_estaciones_de_la_linea = lineas_obj.num_estaciones(linea)

        # Construimos el grafo sin esa línea para ver qué estaciones desaparecen
        grafo_sin_la_linea  = lineas_obj.eliminar_linea(linea)
        vista_sin_la_linea  = grafo_sin_la_linea.a_estaciones()

        # Una estación queda huérfana si ya no aparece en la nueva vista
        # (porque no hay ninguna otra línea que pase por ella)
        estaciones_huerfanas = []
        for estacion in lineas_obj.estaciones_de(linea):
            if estacion not in vista_sin_la_linea:
                estaciones_huerfanas.append(estacion)

        num_huerfanas = len(estaciones_huerfanas)

        # La proporción indica qué fracción de las paradas de esa línea quedan aisladas
        if total_estaciones_de_la_linea > 0:
            proporcion = num_huerfanas / total_estaciones_de_la_linea
        else:
            proporcion = 0.0

        return num_huerfanas, proporcion

    def linea_mas_critica(self, lineas_obj):
        """Devuelve todas las líneas ordenadas de más a menos crítica.
        Cada elemento es una tupla: (nombre_linea, num_huerfanas, proporcion)."""
        tabla_criticidad = []
        for nombre_linea in lineas_obj.lineas():
            num_huerfanas, proporcion = self.criticidad_de_linea(lineas_obj, nombre_linea)
            tabla_criticidad.append((nombre_linea, num_huerfanas, proporcion))

        # Ordenamos: primero por número absoluto, después por proporción (desempate)
        tabla_criticidad.sort(key=lambda fila: (fila[1], fila[2]), reverse=True)
        return tabla_criticidad

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 9 — Ruta con un solo transbordo
    # ★
    # ★ El enunciado dice: "una función que nos diga si hay una ruta
    # ★ entre dos estaciones con UN SOLO transbordo."
    # ★
    # ★ ESTRATEGIA:
    # ★   Para cada línea L1 que pase por el origen, y cada línea L2
    # ★   que pase por el destino, buscamos si L1 y L2 comparten alguna
    # ★   estación en común → esa sería la estación de transbordo.
    # ★
    # ★ Devuelve (linea_origen, estacion_transbordo, linea_destino)
    # ★ o None si no existe ninguna combinación posible.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def ruta_un_transbordo(self, lineas_obj, origen, destino):
        """Devuelve (L1, estacion_transbordo, L2) o None."""
        # Comprobaciones básicas
        if origen not in self._estaciones_y_sus_lineas:
            return None
        if destino not in self._estaciones_y_sus_lineas:
            return None
        if lineas_obj.en_la_misma_linea(origen, destino):
            return None  # Ya se puede ir directo, no necesita transbordo

        lineas_del_origen  = self._estaciones_y_sus_lineas[origen]
        lineas_del_destino = self._estaciones_y_sus_lineas[destino]

        # Probamos todas las combinaciones de línea del origen con línea del destino
        for linea_del_origen in lineas_del_origen:
            estaciones_de_L1 = set(lineas_obj.estaciones_de(linea_del_origen))

            for linea_del_destino in lineas_del_destino:
                if linea_del_origen == linea_del_destino:
                    continue  # Es la misma línea → ya sería sin transbordo

                estaciones_de_L2 = set(lineas_obj.estaciones_de(linea_del_destino))

                # Las estaciones que están en las dos líneas son candidatas a transbordo
                posibles_transbordos = estaciones_de_L1 & estaciones_de_L2

                if len(posibles_transbordos) > 0:
                    # Encontramos un transbordo válido
                    estacion_transbordo = next(iter(posibles_transbordos))
                    return (linea_del_origen, estacion_transbordo, linea_del_destino)

        return None  # No existe ruta con un solo transbordo

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 10 — Ruta con N transbordos (generalización)
    # ★
    # ★ El enunciado dice: "¿Se puede generalizar? Pregunte a su IA."
    # ★
    # ★ ESTRATEGIA — BFS sobre el GRAFO DE LÍNEAS:
    # ★   En vez de hacer BFS sobre estaciones, lo hacemos sobre líneas.
    # ★   · Cada "nodo" es una línea (no una estación).
    # ★   · Dos líneas son "vecinas" si comparten alguna estación.
    # ★   · Cada salto en el BFS = un transbordo.
    # ★   · El primer camino que llega a una línea del destino es el
    # ★     camino con MENOS transbordos posibles.
    # ★
    # ★ Devuelve (lista_de_pasos, numero_de_transbordos) donde
    # ★ cada paso es (nombre_linea, estacion_de_transbordo_o_None).
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def ruta_n_transbordos(self, lineas_obj, origen, destino, max_transbordos=4):
        """Devuelve ([(linea, transbordo_o_None), ...], n_transbordos) o None."""
        # Comprobaciones básicas
        if origen not in self._estaciones_y_sus_lineas:
            return None
        if destino not in self._estaciones_y_sus_lineas:
            return None
        if origen == destino:
            return ([], 0)

        lineas_del_origen  = self._estaciones_y_sus_lineas[origen]
        lineas_del_destino = self._estaciones_y_sus_lineas[destino]

        # Caso 0 transbordos: hay una línea que pasa por las dos estaciones
        lineas_en_comun = lineas_del_origen & lineas_del_destino
        if len(lineas_en_comun) > 0:
            linea_directa = next(iter(lineas_en_comun))
            return ([(linea_directa, None)], 0)

        # BFS sobre líneas.
        # de_donde_vengo guarda, para cada línea descubierta:
        #   None   → es una de las líneas del origen (punto de partida)
        #   (linea_padre, estacion_transbordo) → llegamos desde linea_padre
        #                                         haciendo transbordo en esa estación
        de_donde_vengo = {}
        for linea in lineas_del_origen:
            de_donde_vengo[linea] = None  # las líneas del origen son el punto de partida

        cola_de_lineas              = deque(list(lineas_del_origen))
        linea_que_llega_al_destino  = None

        while len(cola_de_lineas) > 0 and linea_que_llega_al_destino is None:
            linea_actual = cola_de_lineas.popleft()

            # ¿Esta línea ya llega al destino?
            if linea_actual in lineas_del_destino:
                linea_que_llega_al_destino = linea_actual
                break

            # Buscamos las líneas vecinas: las que comparten estación con linea_actual
            estaciones_de_la_linea_actual = set(lineas_obj.estaciones_de(linea_actual))

            for estacion_de_paso in estaciones_de_la_linea_actual:
                # Qué otras líneas pasan por esta estación
                lineas_que_pasan_aqui = self._estaciones_y_sus_lineas.get(estacion_de_paso, set())

                for linea_vecina in lineas_que_pasan_aqui:
                    if linea_vecina in de_donde_vengo:
                        continue  # Ya la visitamos, no la procesamos otra vez

                    # Guardamos el camino: llegamos a linea_vecina desde linea_actual
                    # haciendo transbordo en estacion_de_paso
                    de_donde_vengo[linea_vecina] = (linea_actual, estacion_de_paso)

                    if linea_vecina in lineas_del_destino:
                        linea_que_llega_al_destino = linea_vecina
                        cola_de_lineas.clear()  # Paramos el BFS
                        break

                    cola_de_lineas.append(linea_vecina)

                if linea_que_llega_al_destino is not None:
                    break

        # Si no encontramos ninguna ruta hasta el destino
        if linea_que_llega_al_destino is None:
            return None

        # Reconstruimos el camino yendo hacia atrás desde el destino al origen
        camino_al_reves = []
        linea_actual = linea_que_llega_al_destino

        while de_donde_vengo[linea_actual] is not None:
            linea_padre, estacion_transbordo = de_donde_vengo[linea_actual]
            camino_al_reves.append((linea_actual, estacion_transbordo))
            linea_actual = linea_padre

        # La última línea es la del origen y no tiene estación de transbordo
        camino_al_reves.append((linea_actual, None))

        # Lo invertimos para que vaya de origen a destino
        camino = list(reversed(camino_al_reves))

        numero_de_transbordos = len(camino) - 1
        if numero_de_transbordos > max_transbordos:
            return None

        return (camino, numero_de_transbordos)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 2b — Conversión Estaciones → Lineas
    # ★
    # ★ El enunciado dice: "otra que haga lo recíproco, es decir, que
    # ★ dado un objeto Estaciones cree su correspondiente objeto Lineas."
    # ★
    # ★ Aquí hacemos el recorrido inverso: en vez de
    # ★ "estación → conjunto de líneas", construimos
    # ★ "línea → lista de estaciones".
    # ★
    # ★ Este método vive en Estaciones porque es esta clase la que
    # ★ tiene la información y la reorganiza en la otra dirección.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def a_lineas(self):
        """Construye y devuelve un objeto Lineas equivalente."""
        # Import local para evitar import circular entre los dos ficheros
        from lineas import Lineas

        # Para cada línea acumulamos la lista de estaciones que la forman
        lineas_con_sus_estaciones = defaultdict(list)
        for estacion, conjunto_lineas in self._estaciones_y_sus_lineas.items():
            for nombre_linea in conjunto_lineas:
                lineas_con_sus_estaciones[nombre_linea].append(estacion)

        return Lineas(dict(lineas_con_sus_estaciones), self._lineas_circulares)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 3 — Igualdad de contenido
    # ★
    # ★ Misma idea que en Lineas.__eq__: comparamos por contenido,
    # ★ no por referencia. Así el round-trip da True con ==
    # ★ aunque sea False con is (objetos distintos en memoria).
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def __eq__(self, otra):
        """Compara dos objetos Estaciones por su contenido, no por su referencia."""
        if not isinstance(otra, Estaciones):
            return NotImplemented

        # Deben tener exactamente las mismas estaciones
        mis_estaciones = set(self._estaciones_y_sus_lineas.keys())
        sus_estaciones = set(otra._estaciones_y_sus_lineas.keys())
        if mis_estaciones != sus_estaciones:
            return False

        # Para cada estación, el conjunto de líneas debe ser el mismo
        for estacion in self._estaciones_y_sus_lineas:
            if self._estaciones_y_sus_lineas[estacion] != otra._estaciones_y_sus_lineas[estacion]:
                return False

        # Y las líneas circulares deben coincidir
        return self._lineas_circulares == otra._lineas_circulares

    __hash__ = None  # No se puede usar como clave de diccionario

    def __repr__(self):
        return f"Estaciones({len(self._estaciones_y_sus_lineas)} estaciones)"
