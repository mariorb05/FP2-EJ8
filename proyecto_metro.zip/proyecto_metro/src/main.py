"""
main.py
-------
Punto de entrada del programa.

REGLA DEL ENUNCIADO: no se definen funciones aquí.
Toda la lógica vive dentro de las clases. Este fichero solo
invoca sus métodos y muestra los resultados por pantalla.

EJERCICIOS DEL ENUNCIADO DEMOSTRADOS AQUÍ
==========================================
  ★ EJERCICIO 1   — Carga del Excel + verificación de coherencia
  ★ EJERCICIO 2   — Construir las dos vistas (Lineas y Estaciones)
  ★ EJERCICIO 3   — Round-trip + diferencia entre == e is
  ★ EJERCICIO 4b  — Estaciones con más líneas
  ★ EJERCICIO 4+8 — ¿En la misma línea? + ruta sin transbordo
  ★ EJERCICIO 5   — Detectar líneas circulares
  ★ EJERCICIO 6b  — ¿El grafo completo es conexo?
  ★ EJERCICIO 6c  — Criticidad: qué línea deja más estaciones aisladas
  ★ EJERCICIO 6b  — ¿Qué líneas se pueden quitar sin desconectar la red?
  ★ EJERCICIO 9   — Ruta con un transbordo
  ★ EJERCICIO 10  — Ruta con N transbordos (generalización con BFS)
"""

from pathlib import Path
from estacion  import Estacion
from lineas    import Lineas
from estaciones import Estaciones


# ==============================================================
# Localizar el Excel automáticamente en la carpeta datos/
# Buscamos el primer .xlsx que haya, así el código funciona
# aunque el fichero se renombre o tenga tildes en el nombre.
# ==============================================================
DIR_DATOS     = Path(__file__).resolve().parent.parent / "datos"
archivos_xlsx = sorted(DIR_DATOS.glob("*.xlsx"))

if not archivos_xlsx:
    raise FileNotFoundError(
        f"No se encontró ningún .xlsx en {DIR_DATOS}. "
        "Coloca el Excel en esa carpeta y vuelve a ejecutar."
    )

RUTA_EXCEL = archivos_xlsx[0]


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 1 — Leer el Excel y verificar coherencia
# ★
# ★ desde_excel lee el fichero y comprueba automáticamente que
# ★ el número de estaciones declarado en col C coincide con las
# ★ estaciones reales de col B. Si no cuadra, lanza un error.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print("=" * 70)
print("EJERCICIO 1 — Carga del Excel y verificación de coherencia")
print("=" * 70)
print(f"Leyendo: {RUTA_EXCEL}")

vista_lineas = Lineas.desde_excel(RUTA_EXCEL)
print(f"OK · {vista_lineas}")
print()

for nombre_linea in vista_lineas.lineas():
    n_estaciones = vista_lineas.num_estaciones(nombre_linea)
    es_circ      = " (circular)" if vista_lineas.es_circular(nombre_linea) else ""
    print(f"   · {nombre_linea}: {n_estaciones} estaciones{es_circ}")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 2 — Construir la vista Estaciones a partir de Lineas
# ★
# ★ a_estaciones() recorre el diccionario interno de Lineas y
# ★ construye el diccionario inverso: estacion → conjunto de líneas.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 2 — Conversión Lineas → Estaciones")
print("=" * 70)

vista_estaciones = vista_lineas.a_estaciones()
print(f"OK · {vista_estaciones}")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 3 — Round-trip y diferencia entre == e is
# ★
# ★ Hacemos el recorrido completo:
# ★   Lineas → Estaciones → Lineas'
# ★   Estaciones → Lineas → Estaciones'
# ★
# ★ == compara CONTENIDO   → esperamos True  (misma información)
# ★ is compara REFERENCIA  → esperamos False (objetos distintos en memoria)
# ★
# ★ Si no hubiéramos definido __eq__ en las clases, == también
# ★ daría False porque Python compararía referencias por defecto.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 3 — Round-trip: igualdad (==) vs identidad (is)")
print("=" * 70)

# Conversión de ida y vuelta
vista_lineas_2     = vista_estaciones.a_lineas()
vista_estaciones_2 = vista_lineas_2.a_estaciones()

print("¿vista_lineas == vista_lineas_2 ?           ->", vista_lineas == vista_lineas_2)
print("¿vista_lineas is vista_lineas_2 ?           ->", vista_lineas is vista_lineas_2)
print(f"id(vista_lineas)   = {id(vista_lineas)}")
print(f"id(vista_lineas_2) = {id(vista_lineas_2)}   ← dirección de memoria distinta")
print()
print("¿vista_estaciones == vista_estaciones_2 ?   ->", vista_estaciones == vista_estaciones_2)
print("¿vista_estaciones is vista_estaciones_2 ?   ->", vista_estaciones is vista_estaciones_2)
print()
print("Conclusión:")
print("  == True  → tienen el mismo contenido (igualdad)")
print("  is False → son objetos distintos en memoria (identidad)")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 4b — Estaciones con más líneas
# ★
# ★ Buscamos las estaciones que son el mayor "nudo" de la red,
# ★ es decir, aquellas por las que pasan más líneas distintas.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 4b — Estaciones con más líneas")
print("=" * 70)

maximo_lineas, estaciones_ganadoras = vista_estaciones.estaciones_con_mas_lineas()
print(f"Máximo nº de líneas en una estación: {maximo_lineas}")
for estacion in estaciones_ganadoras:
    sus_lineas = sorted(vista_estaciones.lineas_de(estacion))
    print(f"   · {estacion}: {sus_lineas}")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 5 — Detectar líneas circulares
# ★
# ★ Se muestra al imprimir la lista de líneas en el EJERCICIO 1.
# ★ La Linea 6 aparece marcada como "(circular)".
# ★ (ya incluido arriba, no se repite aquí)
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 4 + 8 — ¿En la misma línea? + ruta sin transbordo
# ★
# ★ en_la_misma_linea comprueba si dos estaciones comparten línea.
# ★ ruta_sin_transbordo devuelve además el subtramo de estaciones.
# ★
# ★ Probamos pares con ruta directa y pares sin ella para ver
# ★ cómo responde el programa en los dos casos.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIOS 4 + 8 — Ruta sin transbordo")
print("=" * 70)

PARES_PRUEBA = [
    ("Sol",           "Atocha – Renfe"),   # Linea 1: ruta directa
    ("Bilbao",        "Tribunal"),          # Linea 1: ruta directa, solo 2 paradas
    ("Sol",           "Manuel Becerra"),    # Linea 2: ruta directa
    ("Sol",           "Alameda de Osuna"), # Sin línea directa → requiere transbordo
]

for origen, destino in PARES_PRUEBA:
    lineas_comunes = vista_lineas.en_la_misma_linea(origen, destino)

    if len(lineas_comunes) > 0:
        # Hay ruta directa: mostramos la línea y cuántas paradas tiene el tramo
        nombre_linea, tramo = vista_lineas.ruta_sin_transbordo(origen, destino)
        print(f"   {origen} → {destino}:")
        print(f"      directo por {nombre_linea} ({len(tramo)} paradas)")
    else:
        # No hay ruta directa
        print(f"   {origen} → {destino}:")
        print(f"      NO hay línea directa (requiere transbordo)")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 6b — ¿El grafo completo es conexo?
# ★
# ★ Un grafo es conexo si desde cualquier estación se puede llegar
# ★ a cualquier otra siguiendo las líneas del metro.
# ★ Lo comprobamos con BFS desde una estación cualquiera.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 6b — ¿El grafo completo es conexo?")
print("=" * 70)

grafo_es_conexo = vista_estaciones.es_conexo(vista_lineas)
print(f"¿El Metro de Madrid (sin líneas ML) es conexo? → {grafo_es_conexo}")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 6c — Criticidad de cada línea
# ★
# ★ Para cada línea calculamos cuántas de sus estaciones quedarían
# ★ huérfanas (sin ninguna otra línea) si esa línea desaparece.
# ★ La tabla aparece ordenada de más a menos crítica.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 6c — Criticidad: estaciones aisladas al suprimir cada línea")
print("=" * 70)

ranking_criticidad = vista_estaciones.linea_mas_critica(vista_lineas)
for nombre_linea, num_huerfanas, proporcion in ranking_criticidad:
    print(f"   · {nombre_linea}: {num_huerfanas} estaciones aisladas ({proporcion:.0%} de la línea)")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIO 6b — ¿Qué líneas se pueden quitar sin desconectar la red?
# ★
# ★ Para cada línea eliminamos esa línea del grafo y comprobamos
# ★ si la red resultante sigue siendo conexa.
# ★ También contamos cuántas estaciones quedan huérfanas.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIO 6b — ¿Qué líneas se pueden suprimir sin desconectar la red?")
print("=" * 70)

for nombre_linea in vista_lineas.lineas():
    # Construimos el grafo sin esa línea
    lineas_sin_esta     = vista_lineas.eliminar_linea(nombre_linea)
    estaciones_sin_esta = lineas_sin_esta.a_estaciones()

    # Comprobamos si la red resultante sigue siendo conexa
    sigue_conexo        = estaciones_sin_esta.es_conexo(lineas_sin_esta)
    estaciones_perdidas = len(vista_estaciones) - len(estaciones_sin_esta)

    if sigue_conexo and estaciones_perdidas == 0:
        resultado = "✓ sigue conexo y ninguna estación queda aislada"
    elif sigue_conexo:
        resultado = f"~ sigue conexo pero {estaciones_perdidas} estaciones quedan sin servicio"
    else:
        resultado = "✗ la red queda DESCONECTADA"

    print(f"   · Suprimir {nombre_linea}: {resultado}")


# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
# ★ EJERCICIOS 9 y 10 — Trayectos con transbordos
# ★
# ★ EJERCICIO 9: ruta_un_transbordo busca exactamente un transbordo.
# ★ EJERCICIO 10: ruta_n_transbordos generaliza con BFS sobre líneas
# ★   y encuentra el camino con el MÍNIMO número de transbordos.
# ★
# ★ Probamos varios trayectos para mostrar los dos casos.
# ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
print()
print("=" * 70)
print("EJERCICIOS 9 y 10 — Trayectos con transbordos")
print("=" * 70)

PARES_CON_TRANSBORDO = [
    ("Aeropuerto T4",      "Sol"),             # necesita transbordos
    ("Príncipe Pío",       "Plaza Elíptica"),  # Linea 6, directo (0 transbordos)
    ("Pinar de Chamartín", "La Fortuna"),      # necesita transbordos
    ("Alameda de Osuna",   "Valdecarros"),     # necesita transbordos
]

for origen, destino in PARES_CON_TRANSBORDO:
    resultado = vista_estaciones.ruta_n_transbordos(
        vista_lineas, Estacion(origen), Estacion(destino)
    )

    if resultado is None:
        print(f"   {origen} → {destino}: no se encontró ruta")
        continue

    camino, num_transbordos = resultado

    # Construimos la descripción del camino paso a paso
    descripcion_pasos = []
    for nombre_linea, estacion_transbordo in camino:
        if estacion_transbordo is None:
            descripcion_pasos.append(f"toma {nombre_linea}")
        else:
            descripcion_pasos.append(f"transborda en {estacion_transbordo} → {nombre_linea}")

    print(f"   {origen} → {destino}:")
    print(f"      {num_transbordos} transbordo(s): {' | '.join(descripcion_pasos)}")


print()
print("=" * 70)
print("Fin del programa")
print("=" * 70)
