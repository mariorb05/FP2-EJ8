"""
lineas.py
---------
Clase Lineas: vista del grafo del Metro "por líneas".

Para cada línea guardamos la SECUENCIA ORDENADA de estaciones, porque
el orden importa: es el orden real en que para el tren.

ESTRUCTURA DE DATOS ELEGIDA: dict[str, list[Estacion]]
  - Usamos dict porque así accedemos a las estaciones de "Linea 1" en
    tiempo constante: self._lineas["Linea 1"]
  - Dentro de cada clave usamos list porque el orden importa.
    Un set no serviría porque no guarda orden.

EJERCICIOS DEL ENUNCIADO IMPLEMENTADOS AQUÍ
============================================
  ★ EJERCICIO 1  — Leer el Excel y verificar coherencia
  ★ EJERCICIO 2  — Conversión Lineas → Estaciones  (a_estaciones)
  ★ EJERCICIO 3  — Igualdad de contenido           (__eq__)
  ★ EJERCICIO 4  — ¿Dos estaciones en la misma línea? (en_la_misma_linea)
  ★ EJERCICIO 5  — ¿Es una línea circular?           (es_circular)
  ★ EJERCICIO 6  — Eliminar una línea del grafo       (eliminar_linea)
  ★ EJERCICIO 7b — Línea geográficamente más larga    (linea_mas_larga)
  ★ EJERCICIO 8  — Ruta sin transbordo + tramo        (ruta_sin_transbordo)
"""

from collections import defaultdict
from openpyxl import load_workbook

from estacion import Estacion


class Lineas:

    def __init__(self, lineas=None, circulares=None):
        # Guardamos una copia defensiva del diccionario para que nadie
        # pueda modificarlo desde fuera sin pasar por los métodos.
        self._lineas = {}
        for nombre_linea, lista_estaciones in (lineas or {}).items():
            self._lineas[nombre_linea] = list(lista_estaciones)

        # Conjunto con los nombres de las líneas circulares (ej: "Linea 6")
        self._lineas_circulares = set(circulares or set())

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 1 — Leer el Excel y verificar coherencia
    # ★
    # ★ El enunciado dice: "lo primero es leer el Excel y comprobar
    # ★ que la información es correcta. Es decir que el número de
    # ★ estaciones que tiene cada línea coincide con el número de
    # ★ estaciones que hay en la columna C."
    # ★
    # ★ Formato del Excel:
    # ★   Columna A → nombre de la línea   (ej: "Linea 1")
    # ★   Columna B → todas las estaciones en una celda, separadas por comas
    # ★   Columna C → número total de paradas declarado
    # ★
    # ★ Nota sobre Linea 6 (circular): su celda tiene 29 nombres pero
    # ★ el Excel declara 28 paradas. Eso es porque el primer nombre
    # ★ (Laguna) se repite al final para indicar que la línea cierra
    # ★ el círculo. Detectamos ese caso, descartamos el duplicado y
    # ★ marcamos la línea como circular.
    # ★
    # ★ Usamos @classmethod para crear un constructor alternativo.
    # ★ En lugar de Lineas(...), llamamos Lineas.desde_excel("ruta").
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    @classmethod
    def desde_excel(cls, ruta):
        """Carga el Excel y devuelve un objeto Lineas ya verificado."""
        wb   = load_workbook(ruta, data_only=True)
        hoja = wb.active

        lineas               = {}   # nombre_linea → [Estacion, ...]
        contadores_declarados = {}   # nombre_linea → número declarado en col C
        circulares           = set() # nombres de líneas circulares detectadas

        for fila in hoja.iter_rows(min_row=2, values_only=True):
            # Saltamos filas vacías o la fila de cabecera si aparece en el cuerpo
            if not fila or fila[0] is None:
                continue
            nombre_linea = str(fila[0]).strip()
            if nombre_linea.lower() == "línea":
                continue

            # Columna B: dividimos la celda por comas para obtener cada estación
            celda_estaciones  = str(fila[1]).strip()
            nombres_estaciones = [nombre.strip() for nombre in celda_estaciones.split(",")]

            # Columna C: número de paradas declarado
            total_declarado = int(fila[2])

            # Detectar si es circular: primera y última estación son iguales
            primera = nombres_estaciones[0]
            ultima  = nombres_estaciones[-1]
            es_circular = len(nombres_estaciones) > 1 and primera == ultima

            if es_circular:
                # El último nombre es el cierre del bucle, no una parada nueva
                # Lo eliminamos para no contarlo dos veces
                nombres_estaciones = nombres_estaciones[:-1]
                circulares.add(nombre_linea)

            # Convertimos cada nombre a un objeto Estacion
            lista_estaciones = []
            for nombre in nombres_estaciones:
                lista_estaciones.append(Estacion(nombre))

            lineas[nombre_linea]                = lista_estaciones
            contadores_declarados[nombre_linea] = total_declarado

        # Creamos el objeto y verificamos que los contadores cuadran
        instancia = cls(lineas, circulares)
        instancia._verificar(contadores_declarados)
        return instancia

    def _verificar(self, contadores_declarados):
        """Comprueba que el nº declarado en col C coincide con las filas reales.
        Si hay discrepancias lanza un error con el detalle de cuáles son."""
        problemas = []
        for nombre_linea, total_declarado in contadores_declarados.items():
            total_real = len(self._lineas[nombre_linea])
            if total_declarado != total_real:
                problemas.append(
                    f"  · {nombre_linea}: declarado={total_declarado}, real={total_real}"
                )
        if len(problemas) > 0:
            raise ValueError(
                "Incoherencias en el Excel:\n" + "\n".join(problemas)
            )

    # ------------------------------------------------------------------
    # Consultas básicas
    # Métodos de acceso sencillos que usan otros métodos más avanzados
    # ------------------------------------------------------------------
    def lineas(self):
        """Devuelve la lista de nombres de todas las líneas."""
        return list(self._lineas.keys())

    def estaciones_de(self, linea):
        """Devuelve la lista ordenada de estaciones de una línea."""
        return list(self._lineas[linea])

    def num_estaciones(self, linea):
        """Devuelve el número de estaciones de una línea."""
        return len(self._lineas[linea])

    def todas_las_estaciones(self):
        """Devuelve el conjunto de todas las estaciones (sin duplicados).
        Una estación que aparece en varias líneas solo se cuenta una vez."""
        todas = set()
        for lista_estaciones in self._lineas.values():
            todas.update(lista_estaciones)
        return todas

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 5 — ¿Es una línea circular?
    # ★
    # ★ El enunciado dice: "tenga en cuenta que puede haber líneas
    # ★ circulares, escriba un método que nos devuelva si una línea
    # ★ es circular."
    # ★
    # ★ Una línea circular es aquella cuyo recorrido forma un bucle
    # ★ cerrado: el tren vuelve al punto de partida sin dar la vuelta.
    # ★ En el Metro de Madrid, la Linea 6 es circular.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def es_circular(self, linea):
        """Devuelve True si la línea es circular, False si no lo es."""
        lista_estaciones = self._lineas[linea]

        # Una línea sin estaciones no puede ser circular
        if len(lista_estaciones) == 0:
            return False

        # Caso 1: la marcamos como circular al leer el Excel
        # (primera y última estación eran iguales en el fichero)
        if linea in self._lineas_circulares:
            return True

        # Caso 2: aunque no se marcó al cargar, comprobamos si
        # la primera y última estación coinciden en la lista actual
        primera_estacion = lista_estaciones[0]
        ultima_estacion  = lista_estaciones[-1]
        if len(lista_estaciones) > 1 and primera_estacion == ultima_estacion:
            return True

        return False

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 4 — ¿Dos estaciones están en la misma línea?
    # ★
    # ★ El enunciado dice: "una función que responda si dos estaciones
    # ★ están en la misma línea."
    # ★
    # ★ Devuelve la lista de líneas que contienen ambas estaciones a la vez.
    # ★ Si devuelve una lista vacía → no comparten ninguna línea directa.
    # ★ Si devuelve una o más → se puede ir sin transbordo por cualquiera.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def en_la_misma_linea(self, est1, est2):
        """Devuelve la lista de líneas que contienen ambas estaciones."""
        # Aceptamos tanto un string ("Sol") como un objeto Estacion
        if isinstance(est1, Estacion):
            estacion_1 = est1
        else:
            estacion_1 = Estacion(est1)

        if isinstance(est2, Estacion):
            estacion_2 = est2
        else:
            estacion_2 = Estacion(est2)

        # Buscamos en todas las líneas cuáles contienen a las dos estaciones
        lineas_comunes = []
        for nombre_linea, lista_estaciones in self._lineas.items():
            if estacion_1 in lista_estaciones and estacion_2 in lista_estaciones:
                lineas_comunes.append(nombre_linea)

        return lineas_comunes

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 6 — Eliminar una línea del grafo
    # ★
    # ★ El enunciado dice: "Implemente una función que elimine una
    # ★ línea. Quitar una línea no es suprimir las estaciones, solo
    # ★ las conexiones de esa línea."
    # ★
    # ★ Importante: devolvemos un objeto NUEVO, no modificamos el original.
    # ★ Así podemos hacer pruebas sin perder el grafo original.
    # ★
    # ★ Las estaciones de la línea eliminada pueden seguir existiendo
    # ★ en el grafo si otras líneas también pasan por ellas.
    # ★ Por eso decimos "quitar una línea ≠ borrar sus estaciones".
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def eliminar_linea(self, linea):
        """Devuelve un nuevo objeto Lineas sin la línea indicada."""
        if linea not in self._lineas:
            raise KeyError(f"Línea desconocida: '{linea}'")

        # Copiamos todas las líneas excepto la que queremos eliminar
        lineas_resultado = {}
        for nombre_linea, lista_estaciones in self._lineas.items():
            if nombre_linea != linea:
                lineas_resultado[nombre_linea] = list(lista_estaciones)

        # Si la línea eliminada era circular, la quitamos de ese conjunto también
        circulares_resultado = self._lineas_circulares - {linea}

        return Lineas(lineas_resultado, circulares_resultado)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 8 — Ruta sin transbordo
    # ★
    # ★ El enunciado dice: "primero una función que diga si se puede
    # ★ llegar de una estación a otra sin transbordo y devuelva la línea."
    # ★
    # ★ Ampliamos el enunciado: además de la línea, devolvemos el
    # ★ subtramo ordenado de estaciones entre origen y destino.
    # ★
    # ★ Devuelve None si no existe línea directa entre ambas estaciones.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def ruta_sin_transbordo(self, origen, destino):
        """Devuelve (nombre_linea, [estaciones del tramo]) o None."""
        # Paso 1: comprobar si hay alguna línea que las conecte directamente
        lineas_comunes = self.en_la_misma_linea(origen, destino)
        if len(lineas_comunes) == 0:
            return None  # No hay ruta directa, haría falta transbordo

        # Tomamos la primera línea común que encontramos
        nombre_linea     = lineas_comunes[0]
        lista_estaciones = self._lineas[nombre_linea]

        # Paso 2: asegurar que trabajamos con objetos Estacion
        if isinstance(origen, Estacion):
            estacion_origen = origen
        else:
            estacion_origen = Estacion(origen)

        if isinstance(destino, Estacion):
            estacion_destino = destino
        else:
            estacion_destino = Estacion(destino)

        # Paso 3: encontrar la posición de cada estación en la lista
        # index() devuelve la posición (0, 1, 2...) de un elemento en la lista
        pos_origen  = lista_estaciones.index(estacion_origen)
        pos_destino = lista_estaciones.index(estacion_destino)

        # Paso 4: extraer el subtramo entre las dos posiciones
        if pos_origen <= pos_destino:
            # El origen aparece antes en la lista → cortamos de izquierda a derecha
            # Ej: pos_origen=2, pos_destino=5 → posiciones [2, 3, 4, 5]
            tramo = lista_estaciones[pos_origen : pos_destino + 1]
        else:
            # El destino aparece antes en la lista → cortamos y damos la vuelta
            # Ej: pos_origen=5, pos_destino=2 → cortamos [2,3,4,5] y revertimos
            tramo = lista_estaciones[pos_destino : pos_origen + 1]
            tramo = list(reversed(tramo))

        return nombre_linea, tramo

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 7b — Línea geográficamente más larga
    # ★
    # ★ El enunciado dice: "Añadir coordenadas geográficas proporciona
    # ★ otro tipo de consultas como línea más larga."
    # ★
    # ★ Sumamos las distancias Haversine entre estaciones contiguas.
    # ★ Si la línea es circular, también sumamos el tramo de vuelta
    # ★ entre la última y la primera estación.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def longitud_geografica(self, linea):
        """Devuelve la longitud total de la línea en km (requiere coordenadas)."""
        lista_estaciones = self._lineas[linea]
        total_km = 0.0

        # Sumamos la distancia entre cada par de estaciones contiguas
        for i in range(len(lista_estaciones) - 1):
            estacion_actual   = lista_estaciones[i]
            estacion_siguiente = lista_estaciones[i + 1]
            total_km += estacion_actual.distancia_a(estacion_siguiente)

        # Si la línea es circular, añadimos también el tramo de cierre
        if self.es_circular(linea) and len(lista_estaciones) > 1:
            total_km += lista_estaciones[-1].distancia_a(lista_estaciones[0])

        return total_km

    def linea_mas_larga(self):
        """Devuelve el nombre de la línea con más kilómetros de recorrido."""
        return max(self._lineas, key=self.longitud_geografica)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 2 — Conversión Lineas → Estaciones
    # ★
    # ★ El enunciado dice: "vamos a construir dos funciones, una tal
    # ★ que dada un objeto Líneas construya uno Estaciones."
    # ★
    # ★ Aquí hacemos el recorrido inverso: en vez de "línea → lista
    # ★ de estaciones", construimos "estación → conjunto de líneas".
    # ★
    # ★ Este método vive en Lineas porque es esta clase la que tiene
    # ★ la información y la reorganiza en la otra dirección.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def a_estaciones(self):
        """Construye y devuelve un objeto Estaciones equivalente."""
        # Import local para evitar import circular entre los dos ficheros
        from estaciones import Estaciones

        # Para cada estación acumulamos el conjunto de líneas que pasan por ella
        mapa = defaultdict(set)
        for nombre_linea, lista_estaciones in self._lineas.items():
            for estacion in lista_estaciones:
                mapa[estacion].add(nombre_linea)

        return Estaciones(dict(mapa), self._lineas_circulares)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 3 — Igualdad de contenido
    # ★
    # ★ El enunciado dice: "Compruebe que funcionan bien, invocando
    # ★ cada función sobre el resultado de la otra y comprobando que
    # ★ el objeto resultado es igual al anterior."
    # ★
    # ★ Sin definir __eq__, Python compararía las referencias de
    # ★ memoria (identidad). Como el round-trip crea objetos nuevos,
    # ★ siempre daría False aunque el contenido sea idéntico.
    # ★
    # ★ Definimos __eq__ por CONTENIDO: dos Lineas son iguales si
    # ★ tienen las mismas líneas con las mismas estaciones (aunque el
    # ★ orden interno haya cambiado por la conversión).
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def __eq__(self, otra):
        """Compara dos objetos Lineas por su contenido, no por su referencia."""
        if not isinstance(otra, Lineas):
            return NotImplemented

        # Deben tener exactamente las mismas líneas
        if set(self._lineas.keys()) != set(otra._lineas.keys()):
            return False

        # Para cada línea, el conjunto de estaciones debe ser el mismo
        # (usamos set para no exigir el mismo orden, ya que la conversión no lo preserva)
        for nombre_linea in self._lineas:
            mis_estaciones = set(self._lineas[nombre_linea])
            sus_estaciones = set(otra._lineas[nombre_linea])
            if mis_estaciones != sus_estaciones:
                return False

        # Y las líneas circulares deben coincidir
        return self._lineas_circulares == otra._lineas_circulares

    # __hash__ = None indica que este objeto no puede usarse como clave
    # de diccionario. Lo ponemos porque hemos definido __eq__.
    __hash__ = None

    def __repr__(self):
        total_estaciones = len(self.todas_las_estaciones())
        return f"Lineas({len(self._lineas)} líneas, {total_estaciones} estaciones únicas)"
