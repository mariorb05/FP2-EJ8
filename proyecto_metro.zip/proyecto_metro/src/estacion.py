"""
estacion.py
-----------
Clase Estacion.

El enunciado dice que cuando añadimos coordenadas geográficas, una
estación ya no es solo un nombre: necesita ser una clase con atributos.

EJERCICIOS DEL ENUNCIADO IMPLEMENTADOS AQUÍ
============================================
  ★ EJERCICIO 0   — Clase Estacion con coordenadas geográficas opcionales
  ★ EJERCICIO 0b  — Distancia Haversine entre dos estaciones
  ★ EJERCICIO E/I — __eq__ y __hash__: igualdad vs identidad
"""

from math import radians, sin, cos, asin, sqrt


class Estacion:

    # Radio medio de la Tierra en km, necesario para la fórmula Haversine
    _RADIO_TIERRA_KM = 6371.0

    def __init__(self, nombre, latitud=None, longitud=None):
        # Validación: el nombre no puede estar vacío
        if not isinstance(nombre, str) or not nombre.strip():
            raise ValueError("El nombre de la estación debe ser una cadena no vacía")

        # Guardamos los atributos con _ para indicar que son privados
        self._nombre   = nombre.strip()
        self._latitud  = latitud    # None si no se han asignado coordenadas
        self._longitud = longitud   # None si no se han asignado coordenadas

    # ------------------------------------------------------------------
    # Propiedades de solo lectura
    # Usamos @property para que se pueda leer est.nombre pero no
    # asignar est.nombre = "otro" desde fuera de la clase
    # ------------------------------------------------------------------
    @property
    def nombre(self):
        return self._nombre

    @property
    def latitud(self):
        return self._latitud

    @property
    def longitud(self):
        return self._longitud

    def tiene_coordenadas(self):
        """Devuelve True si la estación tiene latitud y longitud asignadas."""
        return self._latitud is not None and self._longitud is not None

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 0 — Clase Estacion con coordenadas geográficas
    # ★
    # ★ El enunciado dice: "Añadir coordenadas geográficas te obliga
    # ★ a añadir información a Estacion que ya no es solo una cadena
    # ★ de caracteres con el nombre, sino que se necesita una clase."
    # ★
    # ★ Las coordenadas son opcionales en el constructor porque al
    # ★ leer el Excel no las tenemos. Se pueden añadir después,
    # ★ por ejemplo tras consultarlas en OpenStreetMap.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def asignar_coordenadas(self, latitud, longitud):
        """Asigna latitud y longitud a la estación."""
        self._latitud  = float(latitud)
        self._longitud = float(longitud)

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO 0b — Distancia geográfica entre estaciones
    # ★
    # ★ El enunciado dice: "la mejor distancia entre coordenadas
    # ★ geográficas no es la distancia euclídea."
    # ★
    # ★ Usamos la fórmula de Haversine, que calcula la distancia real
    # ★ entre dos puntos sobre la superficie esférica de la Tierra.
    # ★ Devuelve la distancia en kilómetros.
    # ★
    # ★ Sirve para calcular "línea más larga" y
    # ★ "estación más cercana a un comercio dado".
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def distancia_a(self, otra):
        """Devuelve la distancia en km entre esta estación y otra, usando Haversine."""
        if not isinstance(otra, Estacion):
            raise TypeError("Se esperaba otra Estacion")
        if not self.tiene_coordenadas() or not otra.tiene_coordenadas():
            raise ValueError(
                f"Faltan coordenadas en '{self._nombre}' o '{otra._nombre}'"
            )

        # Convertimos grados a radianes (la fórmula trabaja en radianes)
        lat1 = radians(self._latitud)
        lon1 = radians(self._longitud)
        lat2 = radians(otra._latitud)
        lon2 = radians(otra._longitud)

        # Diferencias de latitud y longitud
        diferencia_lat = lat2 - lat1
        diferencia_lon = lon2 - lon1

        # Fórmula de Haversine
        a = sin(diferencia_lat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(diferencia_lon / 2) ** 2
        angulo_central = 2 * asin(sqrt(a))

        # Multiplicamos el ángulo por el radio para obtener la distancia real
        return Estacion._RADIO_TIERRA_KM * angulo_central

    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    # ★ EJERCICIO E/I — Igualdad vs Identidad
    # ★
    # ★ El enunciado dice: "a comienzos del curso se estudió la
    # ★ diferencia entre igualdad e identidad y que nunca lo hemos
    # ★ usado. Este es el momento de hacerlo."
    # ★
    # ★ Sin definir __eq__, Python compara por identidad por defecto:
    # ★   Estacion("Sol") == Estacion("Sol")  →  False
    # ★   (son dos objetos distintos en memoria aunque representen lo mismo)
    # ★
    # ★ Al definir __eq__ comparando por nombre:
    # ★   Estacion("Sol") == Estacion("Sol")  →  True   (igualdad)
    # ★   Estacion("Sol") is Estacion("Sol")  →  False  (identidad: siguen siendo objetos distintos)
    # ★
    # ★ __hash__ es obligatorio cuando defines __eq__.
    # ★ Permite usar Estacion como clave de diccionario y como
    # ★ elemento de set, que es imprescindible para la clase Estaciones.
    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    def __eq__(self, otra):
        """Dos estaciones son iguales si tienen el mismo nombre."""
        if not isinstance(otra, Estacion):
            return NotImplemented
        return self._nombre == otra._nombre

    def __hash__(self):
        """El hash se calcula a partir del nombre, igual que la igualdad."""
        return hash(self._nombre)

    # ------------------------------------------------------------------
    # Representación textual del objeto
    # __repr__ es lo que aparece en la consola al inspeccionar el objeto
    # __str__  es lo que aparece al hacer print() o str()
    # ------------------------------------------------------------------
    def __repr__(self):
        if self.tiene_coordenadas():
            return f"Estacion('{self._nombre}', lat={self._latitud}, lon={self._longitud})"
        return f"Estacion('{self._nombre}')"

    def __str__(self):
        return self._nombre
